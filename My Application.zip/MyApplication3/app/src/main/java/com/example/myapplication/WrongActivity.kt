package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class WrongActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wrong)
        val vibrator: Vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        val layout = findViewById<ConstraintLayout>(R.id.Layout2)
        layout.setBackgroundColor(getColor(android.R.color.holo_red_dark))
        val score2 = findViewById<TextView>(R.id.score2)
        score2.text = "Score: $score"
        var vibrationEffect2: VibrationEffect
        val button = findViewById<Button>(R.id.button)

        button.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrationEffect2 = VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                vibrator.cancel()
                vibrator.vibrate(vibrationEffect2)
            }
            val intent = Intent(this, MainActivity::class.java)
            finish()
            startActivity(intent)
            score = 0
        }
    }
}
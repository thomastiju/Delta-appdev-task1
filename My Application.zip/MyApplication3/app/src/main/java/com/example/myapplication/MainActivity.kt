package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.icu.util.Calendar
import android.icu.util.GregorianCalendar
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.lang.Math.random
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt


var score: Int = 0

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val vibrator: Vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        val layout = findViewById<RelativeLayout>(R.id.Layout1)
        layout.setBackgroundColor(getColor(android.R.color.holo_blue_light))
        val randdate = findViewById<TextView>(R.id.randdate)

        val scorebut = findViewById<TextView>(R.id.score)
        scorebut.text = "Score: $score"

        fun randBetween(start: Int, end: Int): Int {
            return start + (random() * (end - start)).roundToInt()
        }

        val gc = GregorianCalendar()
        val year = (1900..2022).random()
        gc[Calendar.YEAR] = year
        val dayOfYear: Int = randBetween(1, gc.getActualMaximum(Calendar.DAY_OF_YEAR))
        var df = SimpleDateFormat("dd-MM-yyyy")
        gc[Calendar.DAY_OF_YEAR] = dayOfYear
        val date: Date? =
            df.parse("${gc[Calendar.DAY_OF_MONTH]}-${gc[Calendar.MONTH] + 1}-${gc[Calendar.YEAR]}")
        randdate.text = df.format(date)
        df = SimpleDateFormat("EEEE")
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)

        val days = arrayListOf(
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"
        )

        val day = df.format(date)
        val buts = mutableListOf<Button>(button1, button2, button3, button4)
        val x = buts[(0..3).random()]
        x.text = day
        println(day)
        val days2 = arrayListOf<String>()
        days.filterTo(days2, { it != day })
        days2.shuffle()
        val buts2 = mutableListOf<Button>()
        buts.filterTo(buts2, { it != x })

        for (i in buts2.indices) {
            buts2[i].text = days2[i]
        }
        var vibrationEffect2: VibrationEffect
        x.setOnClickListener {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrationEffect2 = VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                vibrator.cancel()
                vibrator.vibrate(vibrationEffect2)
            }
            correctans(layout)
        }

        buts2[0].setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrationEffect2 = VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                vibrator.cancel()
                vibrator.vibrate(vibrationEffect2)
            }
            wrongans(layout)
        }
        buts2[1].setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrationEffect2 = VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                vibrator.cancel()
                vibrator.vibrate(vibrationEffect2)
            }
            wrongans(layout)
        }
        buts2[2].setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrationEffect2 = VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                vibrator.cancel()
                vibrator.vibrate(vibrationEffect2)
            }
            wrongans(layout)
        }
    }

    private fun correctans(layout: RelativeLayout) {
        layout.setBackgroundColor(getColor(R.color.Green))
        score += 1
        val intent = intent
        finish()
        startActivity(intent)
    }

    private fun wrongans(layout: RelativeLayout) {
        layout.setBackgroundColor(getColor(android.R.color.holo_red_dark))

        val intent = Intent(this, WrongActivity::class.java)
        finish()
        startActivity(intent)
    }

    //override fun onSaveInstanceState(savedInstanceState: Bundle) {
    //  super.onSaveInstanceState(savedInstanceState)
    // Save UI state changes to the savedInstanceState.
    // This bundle will be passed to onCreate if the process is
    // killed and restarted.
    // savedInstanceState.putBoolean("MyBoolean", true)
    //savedInstanceState.putDouble("myDouble", 1.9)
    //savedInstanceState.putInt("MyInt", score)

    // etc.
}


